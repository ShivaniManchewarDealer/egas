import React from 'react'
import '../Css/about.css'
//import cyl from './about1.jpg'

import cyl from './accessories2.jpg'
function AboutComponent() {
    return (
      
        <div id="main_content">
        
         <div class="top-left">
             <br></br>
             <p>
             Bharat Petroleum Corporation Ltd. (BPCL), a Fortune 500 Company is a major player in Refining 
             and Marketing of petroleum products in India. The Company today is a fully integrated entity 
             after the incorporation of upstream subsidiary Bharat Petro Resources Limited. The Company of
             today offers fully integrated operations with the incorporation of upstream subsidiary Bharat 
             Petro Resources Ltd. in 2005.
             </p>
                <p>
                The company has pioneered Bharat Metal Cutting Gas, an innovative product which acts as substitute
                 to Acetylene. The product has found market in neighbouring countries in Middle East and Sri Lanka. 
                 Bharat Metal Cutting Gas cuts cost while cutting metal.
                BPCL has international standard training capability in SAP implementation and is one the few 
                Indian companies to be nominated by the SAP World Governing Council.
                </p>
        </div>
            
        </div>
       
    )
}
/*

<div class="cardcontent">
            <p>Loremhjhjkhkjhjkknmnjmn j,n,mn,mn,k
            Line 38:50:  Unexpected string concatenation of literals  no-useless-concat
  Line 48:50:  Unexpected string concatenation of literals  no-useless-concat
  Line 57:50:  Unexpected string concatenation of literals  no-useless-concat
            </p>
          </div>
          
*/
export default AboutComponent